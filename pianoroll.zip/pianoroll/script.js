var dupa = '';

function onButtonClick(character) {
dupa = dupa + character;
updateDisplayElement();
}

function removeByIndex(index) {
var array = dupa.split('');
    array.splice(index , 1);
    dupa = array.join('');
}

function onRemoveButtonClick(index) {
var index = document.getElementById("user-input").value;
removeByIndex(index);
updateDisplayElement();
}

function onRemoveLastButtonClick() {
removeByIndex(dupa.length - 1);
updateDisplayElement();
}

function updateDisplayElement() {
document.getElementById("display-object-id").innerHTML = dupa;
}

function onDisplayButtonClick() {
switch(dupa)
{
	case 'A':
	break;
	case 'B':
	break;
	case 'C':
	break;
}
}